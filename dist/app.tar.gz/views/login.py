import flet as ft

def login_view(page: ft.Page, usuario_actual, go_to_menu):
    page.clean()
    page.bgcolor = "white"

    fondo = ft.Container(
        expand=True,
        image=ft.DecorationImage(
            src="assets/fondo.png",
            fit="cover",
        ),
    )

    es_registro = False

    titulo = ft.Text("Iniciar Sesión", size=28, weight=ft.FontWeight.BOLD, color="#040D4A")
    correo_input = ft.TextField(label="Correo electrónico", width=300)
    password_input = ft.TextField(label="Contraseña", password=True, can_reveal_password=True, width=300)
    nombre_input = ft.TextField(label="Nombre completo", width=300, visible=False)
    telefono_input = ft.TextField(label="Teléfono", width=300, visible=False)
    fecha_input = ft.TextField(label="Fecha nacimiento (YYYY-MM-DD)", width=300, visible=False)

    btn_accion = ft.ElevatedButton(content=ft.Text("Ingresar"), width=300)
    btn_alternar = ft.TextButton(content=ft.Text("Crear cuenta nueva"))
    btn_recuperar = ft.TextButton(content=ft.Text("¿Olvidaste contraseña?"))

    def mostrar_mensaje(texto):
        page.snack_bar = ft.SnackBar(ft.Text(texto), open=True)
        page.update()

    def toggle(e):
        nonlocal es_registro
        es_registro = not es_registro
        titulo.value = "Crear Cuenta" if es_registro else "Iniciar Sesión"
        btn_accion.content = ft.Text("Registrarse" if es_registro else "Ingresar")
        btn_alternar.content = ft.Text("Volver a Iniciar Sesión" if es_registro else "Crear cuenta nueva")
        nombre_input.visible = es_registro
        telefono_input.visible = es_registro
        fecha_input.visible = es_registro
        page.update()

    def accion(e):
        if es_registro:
            mostrar_mensaje("Registro simulado (conecte con Firebase después)")
            # Simular registro exitoso y cambiar a login
            toggle(None)
        else:
            correo = correo_input.value.strip()
            password = password_input.value
            if not correo or not password:
                mostrar_mensaje("Ingresa correo y contraseña")
                return
            # Simular login exitoso
            usuario_simulado = {"id": "1", "nombre": "Usuario Prueba", "correo": correo}
            go_to_menu(usuario_simulado)

    def recuperar(e):
        # Diálogo para recuperar contraseña
        def enviar(e):
            if campo_correo.value:
                mostrar_mensaje(f"Enlace enviado a {campo_correo.value} (simulado)")
                dialog.open = False
                page.update()
            else:
                mostrar_mensaje("Ingresa tu correo")
        campo_correo = ft.TextField(label="Correo electrónico", width=300)
        dialog = ft.AlertDialog(
            title=ft.Text("Recuperar contraseña"),
            content=campo_correo,
            actions=[
                ft.TextButton("Cancelar", on_click=lambda e: setattr(dialog, 'open', False) or page.update()),
                ft.ElevatedButton("Enviar", on_click=enviar),
            ],
        )
        page.dialog = dialog
        dialog.open = True
        page.update()

    btn_accion.on_click = accion
    btn_alternar.on_click = toggle
    btn_recuperar.on_click = recuperar

    form = ft.Column(
        [titulo, correo_input, password_input, nombre_input, telefono_input, fecha_input,
         btn_accion, btn_recuperar, btn_alternar],
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=10,
        expand=True,
    )

    page.add(ft.Stack([fondo, form], expand=True))