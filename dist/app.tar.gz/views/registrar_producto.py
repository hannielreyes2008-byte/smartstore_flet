import flet as ft

def registrar_producto_view(page: ft.Page, usuario, go_back):
    page.clean()
    page.bgcolor = "white"

    fondo = ft.Container(
        expand=True,
        image=ft.DecorationImage(src="assets/fondo.png", fit="cover"),
    )

    total_c = 0.0
    total_d = 0.0
    resultado = ft.Text("")
    total_text = ft.Text("Total acumulado: C$0.00 / $0.00", weight=ft.FontWeight.BOLD)

    nombre_input = ft.TextField(label="Nombre", width=300)
    precio_input = ft.TextField(label="Precio C$", width=300)
    stock_input = ft.TextField(label="Cantidad", width=300)
    tasa_input = ft.TextField(label="Tasa del dolar", value="36.5", width=300)

    def calcular(e):
        nonlocal total_c, total_d
        try:
            p = float(precio_input.value)
            c = int(stock_input.value)
            t = float(tasa_input.value)
            n = nombre_input.value
            if not n:
                page.snack_bar = ft.SnackBar(ft.Text("Ingrese nombre"))
                page.snack_bar.open = True
                page.update()
                return
            total_c_producto = p * c
            total_d_producto = total_c_producto / t
            total_c += total_c_producto
            total_d += total_d_producto
            resultado.value = f"{n}: C${total_c_producto:.2f} / ${total_d_producto:.2f}"
            total_text.value = f"Total acumulado: C${total_c:.2f} / ${total_d:.2f}"
            nombre_input.value = ""
            precio_input.value = ""
            stock_input.value = ""
            page.update()
        except:
            page.snack_bar = ft.SnackBar(ft.Text("Error en datos"))
            page.snack_bar.open = True
            page.update()

    form = ft.Container(
        content=ft.Column(
            [
                ft.Text("Registrar Producto (Calculadora)", size=24, weight=ft.FontWeight.BOLD, color="#040D4A"),
                nombre_input, precio_input, stock_input, tasa_input,
                ft.ElevatedButton("Calcular y sumar", on_click=calcular),
                resultado, total_text,
                ft.ElevatedButton("Volver al Menu", on_click=lambda e: go_back()),
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=10,
            expand=True,
        ),
        expand=True,
    )

    page.add(ft.Stack([fondo, form], expand=True))