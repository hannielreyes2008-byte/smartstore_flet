import flet as ft
import threading
import time

def pre_splash_view(page: ft.Page, on_complete):
    page.clean()
    page.bgcolor = "#EFA520"

    content = ft.Column(
        [
            ft.Text("😉", size=80),
            ft.Text("SmartStore", size=32, weight=ft.FontWeight.BOLD, color="white"),
        ],
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=20,
        alignment=ft.MainAxisAlignment.CENTER,
        expand=True,
    )
    page.add(content)
    page.update()

    def desencadenar_cambio():
        time.sleep(3)
        on_complete()

    threading.Thread(target=desencadenar_cambio, daemon=True).start()