import flet as ft
import database as db
import webbrowser

def buscar_producto_view(page: ft.Page, usuario, go_back):
    page.clean()
    page.bgcolor = "white"

    fondo = ft.Container(
        expand=True,
        image=ft.DecorationImage(src="assets/fondo.png", fit="cover"),
    )

    tienda = db.obtener_tienda()
    nombre_tienda = tienda[1] if tienda else "Sin tienda"
    whatsapp = tienda[2] if tienda else None

    buscar_entry = ft.TextField(label="Buscar por nombre", width=200)
    resultados = ft.Column(spacing=10, scroll=ft.ScrollMode.AUTO, height=400)

    def buscar(e):
        resultados.controls.clear()
        productos = db.obtener_productos_por_nombre(buscar_entry.value)
        if not productos:
            resultados.controls.append(ft.Text("No se encontraron productos"))
        else:
            for p in productos:
                card = ft.Container(
                    content=ft.Column(
                        [
                            ft.Text(p[1], weight=ft.FontWeight.BOLD),
                            ft.Text(f"C${p[2]:.2f} / ${p[3]:.2f}"),
                            ft.Text(f"Stock: {p[4]}"),
                            ft.Row(
                                [
                                    ft.ElevatedButton("Reservar", on_click=lambda e, pid=p[0], nom=p[1], s=p[4]: reservar(pid, nom, s)),
                                    ft.ElevatedButton("WhatsApp", on_click=lambda e: abrir_whatsapp()) if whatsapp else ft.Container(),
                                ],
                                spacing=10,
                            ),
                        ],
                        spacing=5,
                    ),
                    bgcolor=ft.Colors.WHITE,
                    border_radius=15,
                    padding=10,
                )
                resultados.controls.append(card)
        page.update()

    def reservar(pid, nom, stock_act):
        if stock_act < 1:
            page.snack_bar = ft.SnackBar(ft.Text("Sin stock"))
            page.snack_bar.open = True
            page.update()
            return

        cantidad_field = ft.TextField(label="Cantidad", value="1", width=200)
        def confirmar(e):
            try:
                cant = int(cantidad_field.value)
                if 1 <= cant <= stock_act:
                    db.agregar_reserva(usuario['id'], pid, cant)
                    page.snack_bar = ft.SnackBar(ft.Text(f"{cant} x '{nom}' reservado"))
                    page.snack_bar.open = True
                    dialog.open = False
                    page.update()
                else:
                    page.snack_bar = ft.SnackBar(ft.Text("Cantidad invalida"))
                    page.snack_bar.open = True
                    page.update()
            except:
                page.snack_bar = ft.SnackBar(ft.Text("Cantidad invalida"))
                page.snack_bar.open = True
                page.update()

        dialog = ft.AlertDialog(
            title=ft.Text(f"Reservar {nom}"),
            content=cantidad_field,
            actions=[
                ft.TextButton("Cancelar", on_click=lambda e: setattr(dialog, 'open', False) or page.update()),
                ft.ElevatedButton("Reservar", on_click=confirmar),
            ],
        )
        page.dialog = dialog
        dialog.open = True
        page.update()

    def abrir_whatsapp():
        if whatsapp:
            numero = whatsapp.strip()
            if not numero.startswith("+"):
                numero = "+" + numero
            webbrowser.open(f"https://wa.me/{numero}")

    content = ft.Container(
        content=ft.Column(
            [
                ft.Text(f"Buscar Productos - {nombre_tienda}", size=24, weight=ft.FontWeight.BOLD, color="#040D4A"),
                ft.Row([buscar_entry, ft.ElevatedButton("Buscar", on_click=buscar)]),
                resultados,
                ft.ElevatedButton("Volver al Menu", on_click=lambda e: go_back()),
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=20,
            expand=True,
        ),
        expand=True,
    )

    page.add(ft.Stack([fondo, content], expand=True))